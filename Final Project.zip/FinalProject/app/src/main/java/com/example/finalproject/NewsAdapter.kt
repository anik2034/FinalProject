package com.example.finalproject


import android.content.Context
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

class NewsAdapter(val c: Context, val list: List<ArticleResponse?>?) :
    RecyclerView.Adapter<NewsAdapter.NewsViewHolder>() {
    inner class NewsViewHolder(val v: View) : RecyclerView.ViewHolder(v) {
        val sourceName = v.findViewById<TextView>(R.id.sourceName)
        val newsTitle = v.findViewById<TextView>(R.id.newsTitle)
        val author = v.findViewById<TextView>(R.id.author)

    }

    override fun onCreateViewHolder(parent: ViewGroup, p1: Int): NewsViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val v = inflater.inflate(R.layout.news_card, parent, false)
        return NewsViewHolder(v)
    }

    override fun getItemCount(): Int {
        return list?.size ?: 0
    }

    override fun onBindViewHolder(holder: NewsViewHolder, position: Int) {
        val newList = list?.get(position)
        holder.sourceName.text = newList?.source?.name ?: ""
        holder.newsTitle.text = newList?.title
        holder.author.text = newList?.author



    }
}